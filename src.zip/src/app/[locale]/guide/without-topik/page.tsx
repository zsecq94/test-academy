import { Conclusion, Contents, Hero } from './_sections'

export default function WithoutTopikPage() {
  return (
    <div>
      <Hero />
      <Contents />
      <Conclusion />
    </div>
  )
}
